# AI Smart Blind Stick

A student project concept for helping visually impaired people navigate more safely using obstacle sensors and audio/vibration alerts.

## Problem
Visually impaired people can have difficulty detecting obstacles, pits, wet surfaces, and moving objects while walking. This project aims to provide affordable alerts and improve independence.

## Proposed features
- Three ultrasonic sensors (front, left, right) for obstacle detection
- IR sensor input for possible drop/pit detection (requires real-world calibration)
- Water/wet-surface sensor input
- Buzzer and vibration motor alerts
- Planned future extensions: GPS voice navigation, GSM SOS messaging, and camera-based AI object recognition

## Current status
This repository contains a **starter Arduino prototype** for ultrasonic obstacle detection and buzzer/vibration alerts. GPS, GSM, camera/AI recognition, and voice navigation are described as future/optional extensions and are **not implemented in this starter code**.

## Hardware for starter prototype
- Arduino Uno/Nano
- 3 × HC-SR04 ultrasonic sensors
- Buzzer
- Vibration motor (use a suitable transistor/MOSFET driver; do not power a motor directly from an Arduino pin)
- Jumper wires and breadboard
- Optional: IR sensor and water sensor

## Pin mapping
| Component | Arduino pin |
|---|---|
| Front ultrasonic TRIG / ECHO | D2 / D3 |
| Left ultrasonic TRIG / ECHO | D4 / D5 |
| Right ultrasonic TRIG / ECHO | D6 / D7 |
| Buzzer | D8 |
| Vibration motor driver input | D9 |

## Setup
1. Open `arduino/ai_smart_blind_stick.ino` in Arduino IDE.
2. Select your Arduino board and port.
3. Connect the components according to the pin mapping.
4. Upload the sketch.
5. Test on a table in a safe environment before any walking trial.

## Safety
This prototype is an educational aid, not a certified mobility device. It must not replace a traditional white cane, orientation-and-mobility training, or a human guide where needed. Test carefully and do not rely on it near traffic, stairs, or open drains until thoroughly validated.

## Project budget from the presentation
The presentation estimates a total cost of ₹5,320. Actual prices may vary by supplier and component quality.

## Planned improvements
- Add calibrated IR/drop detection
- Add wet-surface detection
- Add GPS and GSM modules with verified wiring and power requirements
- Integrate camera-based object recognition on a Raspberry Pi or suitable edge device
- Conduct user testing with accessibility experts and visually impaired users
