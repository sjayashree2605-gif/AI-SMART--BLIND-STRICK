/*
  AI Smart Blind Stick - Arduino starter prototype
  Features: three HC-SR04 ultrasonic sensors, buzzer, vibration motor driver.
  This starter sketch does NOT implement GPS, GSM, voice navigation, IR pit
  detection, water detection, or camera-based AI recognition.

  IMPORTANT:
  - Do not connect a vibration motor directly to an Arduino pin.
    Use a suitable transistor/MOSFET driver and common ground.
  - This is an educational prototype, not a certified mobility aid.
*/

const int FRONT_TRIG = 2;
const int FRONT_ECHO = 3;
const int LEFT_TRIG  = 4;
const int LEFT_ECHO  = 5;
const int RIGHT_TRIG = 6;
const int RIGHT_ECHO = 7;

const int BUZZER_PIN = 8;
const int VIBRATION_DRIVER_PIN = 9;

const int ALERT_DISTANCE_CM = 100;
const int VERY_CLOSE_DISTANCE_CM = 45;

long readDistanceCm(int trigPin, int echoPin) {
  digitalWrite(trigPin, LOW);
  delayMicroseconds(3);
  digitalWrite(trigPin, HIGH);
  delayMicroseconds(10);
  digitalWrite(trigPin, LOW);

  // Timeout prevents the program hanging if no echo is received.
  unsigned long duration = pulseIn(echoPin, HIGH, 25000UL);
  if (duration == 0) return -1; // no valid echo
  return (long)(duration * 0.0343 / 2.0);
}

void setup() {
  pinMode(FRONT_TRIG, OUTPUT);
  pinMode(FRONT_ECHO, INPUT);
  pinMode(LEFT_TRIG, OUTPUT);
  pinMode(LEFT_ECHO, INPUT);
  pinMode(RIGHT_TRIG, OUTPUT);
  pinMode(RIGHT_ECHO, INPUT);

  pinMode(BUZZER_PIN, OUTPUT);
  pinMode(VIBRATION_DRIVER_PIN, OUTPUT);

  digitalWrite(BUZZER_PIN, LOW);
  digitalWrite(VIBRATION_DRIVER_PIN, LOW);
  Serial.begin(9600);
}

void loop() {
  long frontCm = readDistanceCm(FRONT_TRIG, FRONT_ECHO);
  delay(35); // reduce interference between ultrasonic sensors
  long leftCm = readDistanceCm(LEFT_TRIG, LEFT_ECHO);
  delay(35);
  long rightCm = readDistanceCm(RIGHT_TRIG, RIGHT_ECHO);
  delay(35);

  Serial.print("Front: "); Serial.print(frontCm);
  Serial.print(" cm | Left: "); Serial.print(leftCm);
  Serial.print(" cm | Right: "); Serial.print(rightCm);
  Serial.println(" cm");

  bool obstacleDetected =
      (frontCm > 0 && frontCm <= ALERT_DISTANCE_CM) ||
      (leftCm > 0 && leftCm <= ALERT_DISTANCE_CM) ||
      (rightCm > 0 && rightCm <= ALERT_DISTANCE_CM);

  bool veryClose =
      (frontCm > 0 && frontCm <= VERY_CLOSE_DISTANCE_CM) ||
      (leftCm > 0 && leftCm <= VERY_CLOSE_DISTANCE_CM) ||
      (rightCm > 0 && rightCm <= VERY_CLOSE_DISTANCE_CM);

  if (obstacleDetected) {
    digitalWrite(VIBRATION_DRIVER_PIN, HIGH);
    // Faster beep when an obstacle is very close.
    tone(BUZZER_PIN, 2000);
    delay(veryClose ? 100 : 250);
    noTone(BUZZER_PIN);
    delay(veryClose ? 80 : 250);
  } else {
    digitalWrite(VIBRATION_DRIVER_PIN, LOW);
    noTone(BUZZER_PIN);
    delay(100);
  }
}
